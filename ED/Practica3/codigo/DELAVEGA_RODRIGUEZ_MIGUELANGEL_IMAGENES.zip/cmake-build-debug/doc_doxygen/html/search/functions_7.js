var searchData=
[
  ['operator_3d_60',['operator=',['../classImage.html#aeaa2d687caf48e3c72fc773c70a0e9fa',1,'Image']]],
  ['operator_3d_3d_61',['operator==',['../classImage.html#abca2738115ff5f840afd4321a7ea715b',1,'Image']]]
];
