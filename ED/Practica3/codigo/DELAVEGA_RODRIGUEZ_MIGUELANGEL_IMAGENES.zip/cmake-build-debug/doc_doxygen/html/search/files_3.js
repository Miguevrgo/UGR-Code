var searchData=
[
  ['negativo_2ecpp_47',['negativo.cpp',['../negativo_8cpp.html',1,'']]]
];
