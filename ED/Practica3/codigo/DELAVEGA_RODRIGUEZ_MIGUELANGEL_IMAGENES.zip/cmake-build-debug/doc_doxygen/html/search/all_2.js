var searchData=
[
  ['comparar_2ecpp_2',['comparar.cpp',['../comparar_8cpp.html',1,'']]],
  ['contraste_2ecpp_3',['contraste.cpp',['../contraste_8cpp.html',1,'']]],
  ['crop_4',['Crop',['../classImage.html#aad309b582d08dfd826c5106eaf80eb1e',1,'Image']]]
];
